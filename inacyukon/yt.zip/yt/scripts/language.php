<?php

$myurl = $_SERVER['HTTP_REFERER'];

if( strpos( $myurl, "_e" ) ) {
	$myurl = str_replace( "_e", "_f", $myurl );
} else {
	$myurl = str_replace( "_f", "_e", $myurl );
}

header('Location:' . $myurl);

?>